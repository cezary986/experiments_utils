importScripts(
  "https://www.gstatic.com/firebasejs/9.1.3/firebase-app-compat.js"
);
importScripts(
  "https://www.gstatic.com/firebasejs/9.1.3/firebase-messaging-compat.js"
);

firebase.initializeApp({
  apiKey: "AIzaSyAUR1YoMOMeFA3okMbxe5jSZp5aHvS5PSw",
  authDomain: "experiments-monitor.firebaseapp.com",
  projectId: "experiments-monitor",
  storageBucket: "experiments-monitor.appspot.com",
  messagingSenderId: "569207403734",
  appId: "1:569207403734:web:a514a36a54945024730577",
});

console.log("asdasd");
const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log(
    "[firebase-messaging-sw.js] Received background message ",
    payload
  );
  // Customize notification here
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    icon: 'https://icons.iconarchive.com/icons/paomedia/small-n-flat/1024/sign-error-icon.png',
    body: payload.notification.body
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
